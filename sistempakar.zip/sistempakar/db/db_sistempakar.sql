-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 07, 2025 at 03:32 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_sistempakar`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id_admin` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id_admin`, `username`, `password`) VALUES
(1, 'admin', '12345');

-- --------------------------------------------------------

--
-- Table structure for table `aturan`
--

CREATE TABLE `aturan` (
  `id` int(11) NOT NULL,
  `id_rule` varchar(20) NOT NULL,
  `id_gejala` int(11) NOT NULL,
  `id_solusi` int(11) NOT NULL,
  `cf_pakar` decimal(4,3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `aturan`
--

INSERT INTO `aturan` (`id`, `id_rule`, `id_gejala`, `id_solusi`, `cf_pakar`) VALUES
(1, 'R1', 1, 1, 0.988),
(2, 'R1', 2, 1, 0.988),
(3, 'R1', 3, 1, 0.988),
(4, 'R1', 4, 1, 0.988),
(5, 'R1', 5, 1, 0.988),
(6, 'R2', 6, 2, 0.952),
(7, 'R2', 7, 2, 0.952),
(8, 'R2', 8, 2, 0.952),
(9, 'R2', 9, 2, 0.952),
(10, 'R2', 10, 2, 0.952),
(11, 'R3', 11, 3, 0.962),
(12, 'R3', 12, 3, 0.962),
(13, 'R3', 13, 3, 0.962),
(14, 'R3', 14, 3, 0.962),
(15, 'R3', 15, 3, 0.962),
(16, 'R4', 16, 4, 0.910),
(17, 'R4', 17, 4, 0.910),
(18, 'R4', 18, 4, 0.910),
(19, 'R4', 19, 4, 0.910),
(20, 'R4', 20, 4, 0.910),
(21, 'R5', 21, 5, 0.968),
(22, 'R5', 22, 5, 0.968),
(23, 'R5', 23, 5, 0.968),
(24, 'R5', 24, 5, 0.968),
(25, 'R5', 25, 5, 0.968),
(26, 'R6', 26, 1, 0.958),
(27, 'R6', 27, 1, 0.958),
(28, 'R6', 28, 1, 0.958),
(29, 'R6', 29, 1, 0.958),
(30, 'R6', 30, 1, 0.958);

-- --------------------------------------------------------

--
-- Table structure for table `gejala`
--

CREATE TABLE `gejala` (
  `id_gejala` int(11) NOT NULL,
  `kode_gejala` varchar(10) NOT NULL,
  `nama_gejala` varchar(255) NOT NULL,
  `id_jenis` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `gejala`
--

INSERT INTO `gejala` (`id_gejala`, `kode_gejala`, `nama_gejala`, `id_jenis`) VALUES
(1, 'G01', 'Daun bawah menguning', 1),
(2, 'G02', 'Pertumbuhan tanaman lambat', 1),
(3, 'G03', 'Buah tomat kecil', 1),
(4, 'G04', 'pH tanah < 5.5', 1),
(5, 'G05', 'Suhu > 30°C', 1),
(6, 'G06', 'Tepi daun terbakar', 1),
(7, 'G07', 'Daun menggulung', 1),
(8, 'G08', 'Batang lemah', 1),
(9, 'G09', 'Kelembapan < 50%', 1),
(10, 'G10', 'Suhu > 28°C', 1),
(11, 'G11', 'Daun berwarna keunguan', 2),
(12, 'G12', 'Akar pendek', 2),
(13, 'G13', 'Tanaman kerdil', 2),
(14, 'G14', 'pH tanah < 6.0', 2),
(15, 'G15', 'Kelembapan < 60%', 2),
(16, 'G16', 'Daun muda menggulung', 2),
(17, 'G17', 'Ujung daun mati', 2),
(18, 'G18', 'Akar terganggu', 2),
(19, 'G19', 'pH tanah < 6.0', 3),
(20, 'G20', 'Kelembapan > 80%', 3),
(21, 'G21', 'Daun tua menguning di antara tulang daun', 3),
(22, 'G22', 'Muncul bercak coklat pada daun', 3),
(23, 'G23', 'Daun mudah rontok', 3),
(24, 'G24', 'pH tanah > 7.0', 4),
(25, 'G25', 'Suhu > 25°C', 4),
(26, 'G26', 'Daun muda menguning', 4),
(27, 'G27', 'Warna daun pucat', 4),
(28, 'G28', 'Pertumbuhan daun baru lambat', 4),
(29, 'G29', 'Suhu < 15°C', 4),
(30, 'G30', 'Kelembapan < 50%', 4);

-- --------------------------------------------------------

--
-- Table structure for table `jenis_sayuran`
--

CREATE TABLE `jenis_sayuran` (
  `id_jenis` int(11) NOT NULL,
  `nama_jenis` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `jenis_sayuran`
--

INSERT INTO `jenis_sayuran` (`id_jenis`, `nama_jenis`) VALUES
(1, 'Tomat'),
(2, 'Sawi'),
(3, 'Selada'),
(4, 'Bayam'),
(5, 'Pakcoy');

-- --------------------------------------------------------

--
-- Table structure for table `solusi`
--

CREATE TABLE `solusi` (
  `id_solusi` int(11) NOT NULL,
  `kode_solusi` varchar(20) NOT NULL,
  `deskripsi` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `solusi`
--

INSERT INTO `solusi` (`id_solusi`, `kode_solusi`, `deskripsi`) VALUES
(1, 'S01', 'Gunakan Bokashi / Kompos hijau'),
(2, 'S02', 'Gunakan Abu sekam / Kompos pisang'),
(3, 'S03', 'Gunakan Pupuk tulang / Bokashi'),
(4, 'S04', 'Gunakan Dolomit / Bokashi'),
(5, 'S05', 'Gunakan Abu kayu / Kompos hijau');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id_user` int(11) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id_user`, `nama`, `username`, `password`) VALUES
(1, 'Rafi Maulana', 'Rafi', '123'),
(2, 'Adella Muharomah', 'Adell', '263'),
(3, 'cepiya', 'cepi', '123'),
(4, 'Mwehe', 'mwehe', '123'),
(5, 'dafa', '0112', 'dafamr');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id_admin`);

--
-- Indexes for table `aturan`
--
ALTER TABLE `aturan`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_gejala` (`id_gejala`),
  ADD KEY `id_solusi` (`id_solusi`);

--
-- Indexes for table `gejala`
--
ALTER TABLE `gejala`
  ADD PRIMARY KEY (`id_gejala`),
  ADD KEY `id_jenis` (`id_jenis`);

--
-- Indexes for table `jenis_sayuran`
--
ALTER TABLE `jenis_sayuran`
  ADD PRIMARY KEY (`id_jenis`);

--
-- Indexes for table `solusi`
--
ALTER TABLE `solusi`
  ADD PRIMARY KEY (`id_solusi`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id_admin` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `aturan`
--
ALTER TABLE `aturan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `jenis_sayuran`
--
ALTER TABLE `jenis_sayuran`
  MODIFY `id_jenis` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `aturan`
--
ALTER TABLE `aturan`
  ADD CONSTRAINT `aturan_ibfk_1` FOREIGN KEY (`id_gejala`) REFERENCES `gejala` (`id_gejala`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `aturan_ibfk_2` FOREIGN KEY (`id_solusi`) REFERENCES `solusi` (`id_solusi`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `gejala`
--
ALTER TABLE `gejala`
  ADD CONSTRAINT `gejala_ibfk_1` FOREIGN KEY (`id_jenis`) REFERENCES `jenis_sayuran` (`id_jenis`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
